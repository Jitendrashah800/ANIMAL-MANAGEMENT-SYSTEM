<html>
<head >
    <link type="text/css" rel="stylesheet" href="index1.css">
  <title>Choose category
  </title>

</head>
<body background="ADOPT1.png">
<h1>CHOOSE YOUR PET CATEGORY
<div><a href="dog.php" ><img id="one" src="DOG.jpg" title="hi" alt="hi"></a></div>
<div><a href="cat.php"><img id="two" src="CAT.jpg" title="hi" alt="hi"></a></div>
<div><a href="tortoise.php"><img id="three" src="TORTOISE.jpg" title="hi" alt="hi"></a></div>
<div><a href="rabbit.php"><img id="four"src="RABBIT.jpg" title="hi" alt="hi"></a></div>
<div><a href="cow.php"><img id="five" src="COW.jpg" title="hi" alt="hi"></a></div>
<div><a href="rat.php"><img id="six" src="RAT.jpg" title="hi" alt="hi"></a></div>
</body>
</html>
